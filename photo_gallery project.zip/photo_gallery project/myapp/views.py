from django.shortcuts import render,get_object_or_404
from .forms import ImageForm
from .models import Image,Category
from django.contrib import messages# Create your views here.


def home(request,category_slug=None):
 if request.method == "POST":
  form = ImageForm(request.POST, request.FILES)
  messages.info(request,'upload an image')
  if form.is_valid():
   form.save()
 form = ImageForm()
 img = Image.objects.all()
 category = None
 categories = Category.objects.all()
 image = Image.objects.all()
 if category_slug:
  category = get_object_or_404(Category, slug=category_slug)
  image = image.filter(category=category)
 return render(request, 'myapp/home.html', {'categories': categories,
                                            'category': category,
                                            'image': image,

                                            'img': img, 'form': form})
