from django.urls import path
from . import views
app_name='myapp'
urlpatterns=[
path('', views.home, name='myapp_list'),
     path('<slug:category_slug>', views.home, name='myapp_category'),
]