from django.db import models
from django.urls import  reverse

class Category(models.Model):
 name = models.CharField(max_length=150, db_index=True)
 slug = models.SlugField(unique=True)

 class Meta:
  ordering = ('-name',)

 def __str__(self):
  return self.name

 def get_absolute_url(self):
  return reverse('myapp:myapp_category', args=[self.slug])
# Create your models here.

class Image(models.Model):
 category = models.ForeignKey(Category, on_delete=models.PROTECT, db_constraint=False, default=0)
 photo = models.ImageField(upload_to="myimage")
 